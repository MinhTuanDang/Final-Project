package com.example.finalproject;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class Adapter extends ArrayAdapter<ConstructorGetSet> {
    private static final String LOG_TAG = Adapter.class.getSimpleName();
    public Adapter(Activity context, ArrayList<ConstructorGetSet> news) {
        super(context, 0, news);
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.items, parent, false);
        }


        final ConstructorGetSet cGS = getItem(position);


        ImageView articleThumbnail = listItemView.findViewById(R.id.thumbnail_image_view);
        articleThumbnail.setImageBitmap(formatImageFromBitmap(cGS.getImage()));


        TextView type = (TextView) listItemView.findViewById(R.id.type_text_view);
        type.setText(cGS.getType());


        TextView title = (TextView) listItemView.findViewById(R.id.title_text_view);
        title.setText(cGS.getTitle());


        TextView author = (TextView) listItemView.findViewById(R.id.author_text_view);
        author.setText(cGS.getAuthor());


        TextView publishTime = (TextView) listItemView.findViewById(R.id.date_text_view);
        publishTime.setText(formatPublishTime(cGS.getDate()));
        Button btn = (Button) listItemView.findViewById(R.id.more_button);
        btn.setOnClickListener(v -> {
            Intent myWebLink = new Intent(android.content.Intent.ACTION_VIEW);
            myWebLink.setData(Uri.parse(cGS.getUrl()));
            PackageManager packageManager = getContext().getPackageManager();
            List<ResolveInfo> activities = packageManager.queryIntentActivities(myWebLink, 0);
            boolean isIntentSafe = activities.size() > 0;
            if (isIntentSafe) {
                getContext().startActivity(myWebLink);
            }
        });
        return listItemView;
    }


    private String formatPublishTime(final String time) {
        String rTime = "N.A.";
        if ((time != null) && (!time.isEmpty())) {
            try {
                SimpleDateFormat currentSDF = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                SimpleDateFormat newSDF = new SimpleDateFormat("yyyy.MM.dd / HH:mm");
                rTime = newSDF.format(currentSDF.parse(time));
            } catch (ParseException parseEx) {

                rTime = "N.A.";

                Log.e(LOG_TAG, "Error while parsing the published date", parseEx);
            }
        }

        return rTime;
    }

    private Bitmap formatImageFromBitmap(Bitmap articleThumbnail) {

        Bitmap returnBitmap;

        if (articleThumbnail == null) {
            returnBitmap = BitmapFactory.decodeResource(getContext().getResources(), R.drawable.no_image_available);
        } else {
            returnBitmap = articleThumbnail;
        }
        return returnBitmap;
    }
    private String formatDate(Date dateObject) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("LLL dd, yyyy");
        return dateFormat.format(dateObject);
    }
    private String formatTime(Date dateObject) {
        SimpleDateFormat timeFormat = new SimpleDateFormat("h:mm a");
        return timeFormat.format(dateObject);
    }
}
