package com.example.finalproject;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;


public class QueryUtils {
    private static final String LOG_TAG = QueryUtils.class.getSimpleName();

    private QueryUtils() {
    }

    private static URL createUrl(String stringUrl) {
        URL url = null;
        try {
            url = new URL(stringUrl);
        } catch (MalformedURLException e) {
            Log.e(LOG_TAG, "Problem building the URL ", e);
        }
        return url;
    }


    @SuppressLint("NewApi")
    private static String makeHttpRequest(URL url) throws IOException {
        String jsonResponse = "";
        if (url == null) {
            return jsonResponse;
        }
        HttpURLConnection urlConnection = null;
        InputStream inputStream = null;
        try {
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setReadTimeout(10000);
            urlConnection.setConnectTimeout(15000);
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();
            if (urlConnection.getResponseCode() == 200) {
                inputStream = urlConnection.getInputStream();
                jsonResponse = readFromStream(inputStream);
            } else {
                Log.e(LOG_TAG, "Error response code: " + urlConnection.getResponseCode());
            }
        } catch (IOException e) {
            Log.e(LOG_TAG, "Problem retrieving the JSON results.", e);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (inputStream != null) {

                inputStream.close();
            }
        }
        return jsonResponse;
    }


    private static String readFromStream(InputStream inputStream) throws IOException {
        StringBuilder output = new StringBuilder();
        if (inputStream != null) {
            @SuppressLint({"NewApi", "LocalSuppress"}) InputStreamReader inputStreamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String line = reader.readLine();
            while (line != null) {
                output.append(line);
                line = reader.readLine();
            }
        }
        return output.toString();
    }

    private static List<ConstructorGetSet> extractFeatureFromJson(String constructorgetsetJSON) {
        if (TextUtils.isEmpty(constructorgetsetJSON)) {
            return null;
        }
        List<ConstructorGetSet> constructorgetset = new ArrayList<>();
        try {
            JSONObject baseJsonResponse = new JSONObject(constructorgetsetJSON);
            JSONObject jsonResults = baseJsonResponse.getJSONObject("response");
            JSONArray constructorgetsetArray = jsonResults.getJSONArray("results");
            for (int i = 0; constructorgetsetArray.length() > i; i++) {
                Bitmap thumbnailBitmap = null;
                JSONObject result = constructorgetsetArray.getJSONObject(i);
                JSONObject fields = result.getJSONObject("fields");
                if (fields.has("thumbnail")) {
                    String thumbnail = fields.getString("thumbnail");
                    URL url = new URL(thumbnail);
                    thumbnailBitmap = BitmapFactory.decodeStream(url.openConnection().getInputStream());
                }
                String title = result.getString("webTitle");
                String type = result.getString("type");
                JSONArray tagsArray = result.getJSONArray("tags");
                String author = "";
                int j = 0;
                while (j < tagsArray.length()) {
                    JSONObject tag = tagsArray.getJSONObject(j);
                    if (tag.has("webTitle")) {
                        author = tag.getString("webTitle");
                    } else {
                        author = "unnamed";
                    }
                    j++;
                }
                if (tagsArray.length() == 0) {
                    author = "unnamed";
                }
                String time = result.getString("webPublicationDate");
                String url = result.getString("webUrl");
                constructorgetset.add(new ConstructorGetSet(thumbnailBitmap, title, type, author, time, url));
            }
        } catch (JSONException e) {
            Log.e("QueryUtils", "Problem parsing the earthquake JSON results", e);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return constructorgetset;
    }


    public static List<ConstructorGetSet> fetchEarthquakeData(String requestUrl) {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        URL url = createUrl(requestUrl);
        String jsonResponse = null;
        try {
            jsonResponse = makeHttpRequest(url);
        } catch (IOException e) {
            Log.e(LOG_TAG, "Problem making the HTTP request.", e);
        }
        List<ConstructorGetSet> constructorGetSets = extractFeatureFromJson(jsonResponse);
        return constructorGetSets;
    }


}

