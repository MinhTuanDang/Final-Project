package com.example.finalproject;

import android.annotation.SuppressLint;
import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

@SuppressLint("NewApi")
public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<ConstructorGetSet>>, SharedPreferences.OnSharedPreferenceChangeListener {
    private static final String URL = "https://content.guardianapis.com/search?q=";
    private Adapter theAdapter;
    private TextView theEmptyStateTextView;
    private LoaderManager loaderManagers;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.mipmap.logo);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final ListView newsListView = (ListView) findViewById(R.id.list);
        theAdapter = new Adapter(this, new ArrayList<ConstructorGetSet>());
        newsListView.setAdapter(theAdapter);
        theEmptyStateTextView = (TextView) findViewById(R.id.empty_view);
        newsListView.setEmptyView(theEmptyStateTextView);
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            loaderManagers = getLoaderManager();
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            sharedPreferences.registerOnSharedPreferenceChangeListener(this);
            loaderManagers.initLoader(1, null, this);
        } else {
            View loadingIndicator = findViewById(R.id.loading_indicator);
            loadingIndicator.setVisibility(View.GONE);
            theEmptyStateTextView.setText(R.string.no_internet_connection);
        }
    }


    @Override
    public Loader<List<ConstructorGetSet>> onCreateLoader(int id, Bundle args) {
        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        String tag = sharedPrefs.getString(
                getString(R.string.settings_tag_key), getString(R.string.settings_tag_default));

        String orderBy = sharedPrefs.getString(
                getString(R.string.settings_order_by_key), getString(R.string.settings_order_by_default));
        Uri baseUri = Uri.parse(URL);
        Uri.Builder uriBuilder = baseUri.buildUpon();
        uriBuilder.appendQueryParameter("", tag);
        uriBuilder.appendQueryParameter("order-by", orderBy);
        uriBuilder.appendQueryParameter("section", "technology");
        uriBuilder.appendQueryParameter("show-tags", "contributor");
        uriBuilder.appendQueryParameter("show-fields", "thumbnail");
        uriBuilder.appendQueryParameter("api-key", "f29a4891-6dde-43ca-bbf5-c5db37e235c6");
        return new TheLoader(this, uriBuilder.toString().replace("&=", ""));
    }

    @Override
    public void onLoadFinished(Loader<List<ConstructorGetSet>> loader, List<ConstructorGetSet> data) {
        View loadingIndicator = findViewById(R.id.loading_indicator);
        loadingIndicator.setVisibility(View.GONE);
        theEmptyStateTextView.setText(R.string.no_news);
        theAdapter.clear();
        if (data != null && !data.isEmpty()) {
            theAdapter.addAll(data);
        }
    }

    @Override
    public void onLoaderReset(Loader<List<ConstructorGetSet>> loader) {
        theAdapter.clear();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent settingsIntent = new Intent(this, fragment.class);
            startActivity(settingsIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {

        if (key.contains((getString(R.string.settings_tag_key)))) {
            loaderManagers.restartLoader(1, null, MainActivity.this);
        } else if (key.contains(getString(R.string.settings_order_by_key)))
            loaderManagers.restartLoader(1, null, MainActivity.this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        PreferenceManager.getDefaultSharedPreferences(this).unregisterOnSharedPreferenceChangeListener(this);


    }
}