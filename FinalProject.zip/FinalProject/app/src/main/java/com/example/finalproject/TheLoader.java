package com.example.finalproject;

import android.content.AsyncTaskLoader;
import android.content.Context;

import java.util.List;

import static com.example.finalproject.QueryUtils.fetchEarthquakeData;

public class TheLoader extends AsyncTaskLoader<List<ConstructorGetSet>> {
    private final String myURL;
    public TheLoader(Context context, String url) {
        super(context);
        myURL = url;
    }
    @Override
    protected void onStartLoading() {
        forceLoad();
    }
    @Override
    public List<ConstructorGetSet> loadInBackground() {
        if (myURL == null) {
            return null;
        }
        return fetchEarthquakeData(myURL);

    }
}
