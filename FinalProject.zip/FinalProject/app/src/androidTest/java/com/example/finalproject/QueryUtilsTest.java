package com.example.finalproject;

import junit.framework.TestCase;

public class QueryUtilsTest extends TestCase {

    public void testFetchEarthquakeData() {
    }
}